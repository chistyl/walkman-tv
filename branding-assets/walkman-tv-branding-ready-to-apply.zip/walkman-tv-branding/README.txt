Walkman-TV branding asset replacement package
Source artwork supplied by the user:
- banner.png: 780x438 (16:9), used for drawable density resources
- icon.png: 512x512, used for legacy launcher icons and adaptive foreground

Replace these paths on the intended Walkman-TV branch:
- app/src/main/res/drawable-mdpi/banner.png
- app/src/main/res/drawable-hdpi/banner.png
- app/src/main/res/drawable-xhdpi/banner.png
- app/src/main/res/drawable-xxhdpi/banner.png
- app/src/main/res/drawable-xxxhdpi/banner.png
- app/src/main/res/mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png
- app/src/main/res/mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher_round.png
- app/src/main/res/mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher_foreground.png
- app/src/main/res/drawable/ic_launcher_background.xml

Keep app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml and ic_launcher_round.xml
as-is; they continue referencing the adaptive foreground/background resources.
