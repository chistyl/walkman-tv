#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-.}"
BRANCH="fix/lyrics-fetch-reliability"
EXPECTED_BASE="676eeac2b7b476fedba39f383616bb8ef1898543"

if ! git -C "$REPO" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "錯誤：請將第一個參數指定為 walkman-tv Git 專案目錄。" >&2
  exit 1
fi

CURRENT_BRANCH="$(git -C "$REPO" branch --show-current)"
if [[ "$CURRENT_BRANCH" != "$BRANCH" ]]; then
  echo "錯誤：目前分支是 $CURRENT_BRANCH；本補丁只允許套用到 $BRANCH。" >&2
  exit 1
fi

CURRENT_HEAD="$(git -C "$REPO" rev-parse HEAD)"
if [[ "$CURRENT_HEAD" != "$EXPECTED_BASE" ]]; then
  echo "錯誤：目前 HEAD=$CURRENT_HEAD，預期基準=$EXPECTED_BASE。為避免混版，停止套用。" >&2
  exit 1
fi

if [[ -n "$(git -C "$REPO" status --porcelain)" ]]; then
  echo "錯誤：工作目錄有未提交變更，請先處理，避免覆蓋。" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -R "$SCRIPT_DIR/app/src/main/res/." "$REPO/app/src/main/res/"

git -C "$REPO" add app/src/main/res
git -C "$REPO" commit -m "Replace app icon and banner with supplied branding"
echo "完成素材提交。請推送分支以觸發 GitHub Actions："
echo "git -C \"$REPO\" push origin $BRANCH"
